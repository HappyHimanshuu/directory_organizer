  while  [ `find . -name "*.zip" -type f | wc -l` -gt 0 ] ;
  do
      for i in `find . -name "*.zip" -type f`;
      do
          name=`echo $i | awk 'BEGIN{FS="/"} {print $NF}'`
          path=`echo $i | sed -n -e "s/$name$//p"`
          unzip -o -q $i -d $path/$name'(unpack)' 2> /dev/null
          mv $i $i"^"
          echo $name $path
      done
  done


  for i in `find . -name "*.zip^" -type f` ;
  do
     mv "$i"  `echo "$i" | sed 's/\^//g'`
  done
